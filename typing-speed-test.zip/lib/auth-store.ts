"use client"

import { create } from "zustand"
import type { User } from "@supabase/supabase-js"
import { supabase, type UserProfile } from "./supabase"

interface AuthState {
  user: User | null
  profile: UserProfile | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error?: string }>
  signUp: (email: string, password: string, username: string) => Promise<{ error?: string }>
  signOut: () => Promise<void>
  updateProfile: (updates: Partial<UserProfile>) => Promise<void>
  fetchProfile: () => Promise<void>
  initialize: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  loading: true,

  signIn: async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        return { error: error.message }
      }

      if (data.user) {
        set({ user: data.user })
        await get().fetchProfile()
      }

      return {}
    } catch (error) {
      return { error: "An unexpected error occurred" }
    }
  },

  signUp: async (email: string, password: string, username: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      })

      if (error) {
        return { error: error.message }
      }

      if (data.user) {
        // Update the profile with the username
        const { error: profileError } = await supabase.from("user_profiles").update({ username }).eq("id", data.user.id)

        if (profileError) {
          console.error("Error updating profile:", profileError)
        }

        set({ user: data.user })
        await get().fetchProfile()
      }

      return {}
    } catch (error) {
      return { error: "An unexpected error occurred" }
    }
  },

  signOut: async () => {
    await supabase.auth.signOut()
    set({ user: null, profile: null })
  },

  updateProfile: async (updates: Partial<UserProfile>) => {
    const { user } = get()
    if (!user) return

    try {
      const { error } = await supabase
        .from("user_profiles")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("id", user.id)

      if (error) {
        console.error("Error updating profile:", error)
        return
      }

      await get().fetchProfile()
    } catch (error) {
      console.error("Error updating profile:", error)
    }
  },

  fetchProfile: async () => {
    const { user } = get()
    if (!user) return

    try {
      const { data, error } = await supabase.from("user_profiles").select("*").eq("id", user.id).single()

      if (error) {
        console.error("Error fetching profile:", error)
        return
      }

      set({ profile: data })
    } catch (error) {
      console.error("Error fetching profile:", error)
    }
  },

  initialize: async () => {
    try {
      if (!supabase) {
        console.error("Supabase client not available")
        set({ loading: false })
        return
      }

      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (session?.user) {
        set({ user: session.user })
        await get().fetchProfile()
      }

      // Listen for auth changes
      supabase.auth.onAuthStateChange(async (event, session) => {
        if (session?.user) {
          set({ user: session.user })
          await get().fetchProfile()
        } else {
          set({ user: null, profile: null })
        }
      })

      set({ loading: false })
    } catch (error) {
      console.error("Error initializing auth:", error)
      set({ loading: false })
    }
  },
}))
