"use client"

import { TypingTestApp } from "@/components/typing-test-app"

export default function Home() {
  return <TypingTestApp />
}
